This program simulates neural networks, provided through an input.txt file.  If you want to use a different network, simply edit the existing input.txt file, or pass the executable one as an argument.

Chaining Queries is possible, however, the weights of nodes will remain after the query.  This means that the second query will be very much affected by the first.  (The second query will be affected by context).

If you want an unbiased query, click exit and then reopen the program.